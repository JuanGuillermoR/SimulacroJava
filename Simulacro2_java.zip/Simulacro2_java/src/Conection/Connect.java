package Conection;


import java.sql.Connection;
import java.sql.DriverManager;
public class Connect {

    public static java.sql.Connection connection;

    public static java.sql.Connection conectar(){
        String URL = "jdbc:mysql://bx2u0uig6novsyjbwbb6-mysql.services.clever-cloud.com:3306/bx2u0uig6novsyjbwbb6";
        String user = "uakxecvgunkuy6q9";
        String password = "dn6mv0VbFiZ2JDnvHm80";

        try {
            connection = DriverManager.getConnection(URL,user,password);
            System.out.println("Conexion exitosa");
        }catch (Exception e){
            System.out.println("no se pudo conectar a la base de datos");
        }
        return connection;
    }

    public static  void cerrar(){

        if (connection != null){

            try{
                connection.close();
            }catch (Exception e){
                System.out.println("no se pudo conectar a la base de datos");
            }
        }
    }
}
