package crontoller;


import Entities.InscripcionesEntity;

public class InscripcionesController {
    public boolean create(int id_inscripciones,int id_curso, int id_estudiante){
        return this.InscripcionesController.create(new InscripcionesEntity(id_inscripciones, id_curso, id_estudiante));
    }

    public boolean delete(int id){
        return this.InscripcionesController.delete(id);
    }

    public List<InscripcionesEntity> read(String descripcion){
        return this.CalificacionesController.read(descripcion);
    }

    public List<InscripcionesEntity> readAll (){
        return this.InscripcionesController.readAll();
    }

    public boolean update(int id_inscripciones,int id_curso, int id_estudiante)){
        return this.CalificacionesController.create(new InscripcionesEntity(id_inscripciones, id_curso, id_estudiante));
    }
}
