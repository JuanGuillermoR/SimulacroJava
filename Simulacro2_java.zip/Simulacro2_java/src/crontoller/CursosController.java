package crontoller;

import Entities.cursosEntity;

public class CursosController {
    public boolean create(int id_curso, String nombre_curso){
        return this.CursosController.create(new cursosEntity(id_curso,nombre_curso));
    }

    public boolean delete(int id){
        return this.CursosController.delete(id);
    }

    public List<cursosEntity> read(String nombre_curso){
        return this.CursosController.read(nombre_curso);
    }

    public List<cursosEntity> readAll (){
        return this.CursosController.readAll();
    }

    public boolean update(int id_curso, String nombre_curso){
        return this.CursosController.create(new cursosEntity(id_curso,nombre_curso));
    }
}
