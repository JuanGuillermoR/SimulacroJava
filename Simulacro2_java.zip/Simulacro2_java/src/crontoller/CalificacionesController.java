package crontoller;

import Entities.CalificacionesEntity;

public class CalificacionesController {
    public boolean create(int id_calificaciones, String descripcion, int nota){
        return this.CalificacionesController.create(new CalificacionesEntity(id_calificaciones,descripcion,nota));
    }

    public boolean delete(int id){
        return this.CalificacionesController.delete(id);
    }

    public List<CalificacionesEntity> read(String descripcion){
        return this.CalificacionesController.read(descripcion);
    }

    public List<CalificacionesEntity> readAll (){
        return this.CalificacionesController.readAll();
    }

    public boolean update(int id_calificaciones, String descripcion, int nota){
        return this.CalificacionesController.create(new CalificacionesEntity(id_calificaciones,descripcion,nota));
    }
}
