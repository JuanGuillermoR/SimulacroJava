package crontoller;

import Entities.EstudiantesEntity;

import java.util.Date;

public class EstudiantesController {
    public boolean create(int id_estudiantes, String nombre, String apellido, int num_documento, String email, Date fecha_nacimiento){
        return this.EstudiantesController.create(new EstudiantesEntity(id_estudiantes,nombre,apellido,num_documento,email, fecha_nacimiento));
    }

    public boolean delete(int id){
        return this.EstudiantesController.delete(id);
    }

    public List<EstudiantesEntity> read(String nombre_curso){
        return this.EstudiantesController.read(nombre_curso);
    }

    public List<EstudiantesEntity> readAll (){
        return this.EstudiantesController.readAll();
    }

    public boolean update(int id_estudiantes, String nombre, String apellido, int num_documento, String email, Date fecha_nacimiento){
        return this.EstudiantesController.create(new EstudiantesEntity(id_estudiantes,nombre,apellido,num_documento,email, fecha_nacimiento));
    }
}
