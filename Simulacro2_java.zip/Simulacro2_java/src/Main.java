
import Entities.InscripcionesEntity;
import Entities.cursosEntity;
import Entities.EstudiantesEntity;
import Entities.CalificacionesEntity;
public class Main {

    EstudiantesEntity estudiantes = new EstudiantesEntity("Juan","Alvarez",328791001,"ruizalvarez@gmail.com","10/08/1999");

}