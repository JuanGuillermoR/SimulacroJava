package Entities;

import java.util.Date;

public class EstudiantesEntity {
    private int id_estudiantes;
    public String nombre;
    public String apellido;
    private int num_documento;
    private String email;
    private Date fecha_nacimiento;

    public int getId_estudiantes() {
        return id_estudiantes;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getNum_documento() {
        return num_documento;
    }

    public String getEmail() {
        return email;
    }

    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setId_estudiantes(int id_estudiantes) {
        this.id_estudiantes = id_estudiantes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setNum_documento(int num_documento) {
        this.num_documento = num_documento;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFecha_nacimiento(Date fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public EstudiantesEntity() {
        super();
    }
}
