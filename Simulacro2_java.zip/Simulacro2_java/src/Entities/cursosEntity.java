package Entities;

public class cursosEntity {
    private int id_curso;
    private String nombre_curso;

    public cursosEntity() {
    }

    public cursosEntity(int id_curso, String nombre_curso) {
        this.id_curso = id_curso;
        this.nombre_curso = nombre_curso;
    }

    public int getId_curso() {
        return id_curso;
    }

    public String getNombre_curso() {
        return nombre_curso;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }

    public void setNombre_curso(String nombre_curso) {
        this.nombre_curso = nombre_curso;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

}
