package Entities;

public class CalificacionesEntity {
    private int id_calificaciones;
    public String descripcion;
    private int nota;

    public CalificacionesEntity(int id_calificaciones, String descripcion, int nota) {
        this.id_calificaciones = id_calificaciones;
        this.descripcion = descripcion;
        this.nota = nota;
    }

    public int getId_calificaciones() {
        return id_calificaciones;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setId_calificaciones(int id_calificaciones) {
        this.id_calificaciones = id_calificaciones;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
