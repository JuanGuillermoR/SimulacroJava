package Entities;

public class InscripcionesEntity {
    private int id_inscripciones;
    private int id_curso;
    private  int id_estudiante;

    public int getId_inscripciones() {
        return id_inscripciones;
    }

    public int getId_curso() {
        return id_curso;
    }

    public int getId_estudiante() {
        return id_estudiante;
    }

    public void setId_inscripciones(int id_inscripciones) {
        this.id_inscripciones = id_inscripciones;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }

    public void setId_estudiante(int id_estudiante) {
        this.id_estudiante = id_estudiante;
    }

    public InscripcionesEntity() {
        super();
    }
}
